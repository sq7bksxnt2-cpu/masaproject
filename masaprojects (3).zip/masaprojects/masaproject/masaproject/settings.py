from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-%*esu5z3qdv(fz5k(ms$gbj#&a(b&@9x49bj9a1lbc7iadk4tk'

DEBUG = True

ALLOWED_HOSTS = []

# アプリケーション定義
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'masaapp.apps.MasaappConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'masaproject.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [ BASE_DIR / 'masaapp/templates' ],  # テンプレートディレクトリ
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'masaproject.wsgi.application'

# データベース設定（SQLite）
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# パスワードバリデーション
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# 日本語対応
LANGUAGE_CODE = 'ja'
TIME_ZONE = 'Asia/Tokyo'
USE_I18N = True
USE_TZ = True

# 静的ファイル
STATIC_URL = '/static/'
STATICFILES_DIRS = [ BASE_DIR / 'masaapp/static' ]

# 認証リダイレクト
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'
LOGIN_REDIRECT_URL = 'inventory'
LOGOUT_REDIRECT_URL = 'login'
# ログイン後に表示するページ（ビュー名で指定）
LOGIN_REDIRECT_URL = 'login_success'

# ログアウト後に表示するページ（ビュー名で指定）
LOGOUT_REDIRECT_URL = 'logout_success'

# デフォルトの主キー型
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# メール送信設定（Outlookを使用）
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
DEFAULT_FROM_EMAIL = 'utm2577209@stu.o-hara.ac.jp'       # 送信元メールアドレス
EMAIL_HOST = 'smtp-mail.outlook.com'                     # SMTPサーバー
EMAIL_PORT = 587                                          # TLS用ポート
EMAIL_HOST_USER = 'utm2577209@stu.o-hara.ac.jp'          # ログイン用メールアドレス
EMAIL_HOST_PASSWORD = 'Ma06sa30'                         # パスワード（※環境変数で管理推奨）
EMAIL_USE_TLS = True                                      # TLSを使用
